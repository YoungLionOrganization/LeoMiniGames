# LeoMiniGames Client Integration Overlay

This is an additive Qt 6/Core integration layer. It intentionally does **not** guess existing LeoMiniGames model/service class names.

## What it does

- normalizes legacy/new catalog JSON so missing numeric/string/icon fields do not become QML `undefined`;
- rejects already-expired presigned R2 icon URLs and falls back to stable catalog icon tokens;
- parses server-owned `publisher`, `trust`, `license`, and `native_artifacts` catalog metadata;
- treats missing fields as legacy/unverified Level 1 data;
- never grants Official/Verified badges from `manifest.json` fields;
- disables cached trust for a suspended publisher;
- provides a JSON trust snapshot suitable for storing beside installed-package metadata for offline UI;
- keeps the existing download -> SHA-256 -> install -> `QResource::registerResource()` flow unchanged.

## Merge points

1. Add the two source files to the main client target or link the static library.
2. When a catalog item is decoded, call `CatalogTrustInfo::fromCatalogObject(rawCatalogObject)` and expose the result to the existing model.
3. Render a gold Official badge only for `isOfficial()`. Render the normal verified badge only for `isVerified() && !isOfficial()`.
4. Persist `InstalledTrustSnapshot::serialize()` beside the existing installed package metadata. Do not place this trust snapshot inside the package manifest.
5. Continue verifying the downloaded artifact hash/size exactly as the existing launcher already does.
6. Do not load Level 3 native code solely because `plugin_level == 3`; require server trust/native compatibility and the host's existing native-loader policy.

## Compatibility

Old catalog responses and old RCC packages remain valid. New fields are additive. No package-format or QRC prefix migration is introduced here.

## Build test

```
cmake -S . -B build -DLMG_BUILD_CLIENT_INTEGRATION_TESTS=ON
cmake --build build
./build/lmg_client_trust_tests
```

The current delivery environment does not contain Qt 6 development binaries, so that executable test is supplied but is not reported as executed.
