#!/usr/bin/env python3
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

for path in list(ROOT.rglob("*.cpp")) + list(ROOT.rglob("*.h")):
    text = path.read_text(encoding="utf-8")
    for lineno, line in enumerate(text.splitlines(), 1):
        if re.search(r"=\s*\{\s*\}\s*;", line):
            errors.append(f"{path.relative_to(ROOT)}:{lineno}: bare braced assignment is forbidden")
        if re.search(r"\breturn\s*\{\s*\}\s*;", line):
            errors.append(f"{path.relative_to(ROOT)}:{lineno}: bare braced return is forbidden")

for path in ROOT.rglob("*.json"):
    try:
        json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"{path.relative_to(ROOT)}: invalid JSON: {exc}")

plugins = (
    "XoxPlugin",
    "BlackjackPlugin",
    "MinesweeperPlugin",
    "TwentyFortyEightPlugin",
    "MemoryMatchPlugin",
    "ReactionTapPlugin",
)
main = (ROOT / "src/main.cpp").read_text(encoding="utf-8")
for name in plugins:
    if f"Q_IMPORT_PLUGIN({name})" not in main:
        errors.append(f"src/main.cpp: missing Q_IMPORT_PLUGIN({name})")

if errors:
    print("Source guard FAILED")
    print("\n".join(errors))
    sys.exit(1)
print("Source guard OK")
