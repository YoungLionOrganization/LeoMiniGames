// SPDX-License-Identifier: GPL-3.0-or-later
import QtQuick
import QtQuick.Controls

Item {
    id: root
    signal backRequested()

    function syncViewport() {
        Viewport.update(Math.max(Constants.viewportMinWidth, gameLoader.width),
                        Math.max(Constants.viewportMinHeight, gameLoader.height),
                        Constants.spaceNone, Constants.spaceNone, Screen.devicePixelRatio)
    }

    AppBackground { anchors.fill: parent }

    Column {
        anchors.fill: parent
        spacing: Constants.spaceNone

        ThemeSurface {
            width: parent.width
            height: Constants.n("alias.gameHost.header.height")
            surfaceToken: "surface.panel"
            color: Constants.gameHudBackgroundNormal
            borderColor: Constants.gameHudBorderNormal

            Row {
                anchors.fill: parent
                anchors.margins: Constants.n("alias.gameHost.header.margin")
                spacing: Constants.n("alias.gameHost.header.gap")

                BronzeButton {
                    text: ""
                    iconName: "back"
                    iconSize: Math.round(Constants.n("alias.gameHost.backIcon"))
                    width: Constants.n("alias.gameHost.backSize")
                    height: Constants.n("alias.gameHost.backSize")
                    onClicked: root.backRequested()
                }

                Column {
                    width: parent.width - Constants.n("alias.gameHost.header.height")
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: Constants.n("alias.gameHost.titleGap")
                    Text {
                        width: parent.width
                        text: Lang.text(Games.nameFor(App.currentGameId), Lang.language)
                        color: Constants.gameHudTextNormal
                        font.pixelSize: Constants.n("alias.gameHost.titleFont")
                        font.weight: Constants.typographyHeadingWeight
                        elide: Text.ElideRight
                    }
                    Text {
                        width: parent.width
                        text: Lang.text(Games.descriptionFor(App.currentGameId), Lang.language)
                        color: Constants.textMuted
                        font.pixelSize: Constants.n("alias.gameHost.subtitleFont")
                        elide: Text.ElideRight
                    }
                }
            }
        }

        Item {
            width: parent.width
            height: Math.max(Constants.viewportMinHeight, parent.height - Constants.n("alias.gameHost.header.height"))

            Loader {
                id: gameLoader
                anchors.fill: parent
                source: App.currentGameUrl
                focus: true
                onWidthChanged: root.syncViewport()
                onHeightChanged: root.syncViewport()
                onStatusChanged: {
                    root.syncViewport()
                    if (status === Loader.Ready) {
                        Lifecycle.attach(item, App.currentGameId)
                        Lifecycle.load()
                        Lifecycle.start()
                        forceActiveFocus()
                    } else if (status === Loader.Error) {
                        GameLogger.log("error", "QML game entry failed to load", source.toString(), 0)
                        Audio.play("error")
                    }
                }

                Keys.onPressed: function(event) {
                    if (event.key === Qt.Key_Left || event.key === Qt.Key_A) GameInput.press("move_left")
                    else if (event.key === Qt.Key_Right || event.key === Qt.Key_D) GameInput.press("move_right")
                    else if (event.key === Qt.Key_Up || event.key === Qt.Key_W) GameInput.press("up")
                    else if (event.key === Qt.Key_Down || event.key === Qt.Key_S) GameInput.press("down")
                    else if (event.key === Qt.Key_Space || event.key === Qt.Key_Return) GameInput.press("fire")
                    else if (event.key === Qt.Key_Escape) GameInput.press("pause")
                    else return
                    event.accepted = false
                }
                Keys.onReleased: function(event) {
                    if (event.key === Qt.Key_Left || event.key === Qt.Key_A) GameInput.release("move_left")
                    else if (event.key === Qt.Key_Right || event.key === Qt.Key_D) GameInput.release("move_right")
                    else if (event.key === Qt.Key_Up || event.key === Qt.Key_W) GameInput.release("up")
                    else if (event.key === Qt.Key_Down || event.key === Qt.Key_S) GameInput.release("down")
                    else if (event.key === Qt.Key_Space || event.key === Qt.Key_Return) GameInput.release("fire")
                    else if (event.key === Qt.Key_Escape) GameInput.release("pause")
                    else return
                    event.accepted = false
                }
            }

            ThemeSurface {
                anchors.fill: parent
                visible: gameLoader.status === Loader.Error
                surfaceToken: "surface.overlay"
                color: Constants.background
                Column {
                    anchors.centerIn: parent
                    width: Math.min(parent.width - Constants.n("alias.gameHost.errorInset"), Constants.n("alias.gameHost.error.maxWidth"))
                    spacing: Constants.n("alias.gameHost.errorGap")
                    AppIcon {
                        width: Constants.n("alias.gameHost.errorIcon")
                        height: width
                        name: "error"
                        anchors.horizontalCenter: parent.horizontalCenter
                    }
                    Text {
                        width: parent.width
                        text: qsTr("This game could not be loaded.")
                        color: Constants.text
                        font.pixelSize: Constants.n("alias.gameHost.errorTitleFont")
                        font.weight: Constants.typographyHeadingWeight
                        horizontalAlignment: Text.AlignHCenter
                    }
                    Text {
                        width: parent.width
                        text: GameLogger.lastError
                        color: Constants.textMuted
                        wrapMode: Text.WordWrap
                        horizontalAlignment: Text.AlignHCenter
                        font.pixelSize: Constants.n("alias.gameHost.errorBodyFont")
                    }
                }
            }
        }
    }

    Component.onCompleted: syncViewport()
}
