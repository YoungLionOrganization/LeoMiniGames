// SPDX-License-Identifier: GPL-3.0-or-later
import QtQuick

ThemeSurface {
    id: root
    property string label: ""
    width: Constants.n("alias.playingCard.width")
    height: Constants.n("alias.playingCard.height")
    radius: Constants.n("alias.playingCard.radius")
    color: Constants.playingCardBackground
    borderColor: Constants.primary
    borderWidth: Constants.borderHairline

    readonly property bool redSuit: label.indexOf("♥") >= 0 || label.indexOf("♦") >= 0

    scale: Constants.n("alias.playingCard.enterScale")
    opacity: Constants.n("alias.playingCard.hiddenOpacity")

    Component.onCompleted: {
        if (Settings.animationsEnabled)
            entrance.start()
        else {
            scale = Constants.scaleNormal
            opacity = Constants.opacityFull
        }
    }

    ParallelAnimation {
        id: entrance
        NumberAnimation {
            target: root
            property: "scale"
            to: Constants.scaleNormal
            duration: Constants.motionEnterDuration
            easing.type: Constants.easing("alias.motion.enter.easing")
        }
        NumberAnimation {
            target: root
            property: "opacity"
            to: Constants.opacityFull
            duration: Constants.motionFastDuration
        }
    }

    Text {
        anchors.centerIn: parent
        text: root.label
        color: root.label === "??" ? Constants.surfaceInteractive : (root.redSuit ? Constants.playingCardRedSuit : Constants.playingCardBlackSuit)
        font.pixelSize: root.label === "??" ? Constants.n("alias.playingCard.backFontSize") : Constants.n("alias.playingCard.frontFontSize")
        font.weight: Constants.typographyGameTileWeight
    }
}
