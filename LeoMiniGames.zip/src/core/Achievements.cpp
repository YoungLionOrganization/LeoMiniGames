// SPDX-License-Identifier: GPL-3.0-or-later
#include "Achievements.h"
#include "AppPaths.h"
#include <QCborValue>
#include <QDir>
#include <QFile>
#include <QSaveFile>
#include <QtGlobal>
Achievements::Achievements(AppPaths *paths,QObject *parent):QObject(parent),m_paths(paths){}
QString Achievements::gameId() const{return m_gameId;}
QString Achievements::path() const{if(!m_paths||m_gameId.isEmpty())return QString{};const QString d=m_paths->saves()+QLatin1Char('/')+m_gameId;QDir().mkpath(d);return d+QStringLiteral("/achievements.cbor");}
void Achievements::load(){m_data.clear();QFile f(path());if(!f.open(QIODevice::ReadOnly))return;QCborParserError e;auto v=QCborValue::fromCbor(f.readAll(),&e);if(e.error==QCborError::NoError&&v.isMap())m_data=v.toVariant().toMap();}
void Achievements::persist() const{QSaveFile f(path());if(!f.open(QIODevice::WriteOnly))return;f.write(QCborValue::fromVariant(m_data).toCbor());f.commit();}
void Achievements::activate(const QString &gameId){if(m_gameId==gameId)return;m_gameId=gameId;load();emit changed();}
bool Achievements::isUnlocked(const QString &id) const{return m_data.value(QStringLiteral("u/%1").arg(id),false).toBool();}
bool Achievements::unlock(const QString &id){if(id.isEmpty()||isUnlocked(id))return false;m_data.insert(QStringLiteral("u/%1").arg(id),true);m_data.insert(QStringLiteral("p/%1").arg(id),1.0);persist();emit changed();emit unlocked(id);return true;}
qreal Achievements::progress(const QString &id) const{return qBound<qreal>(0.0,m_data.value(QStringLiteral("p/%1").arg(id),0.0).toReal(),1.0);}
void Achievements::setProgress(const QString &id,qreal p){if(id.isEmpty())return;p=qBound<qreal>(0.0,p,1.0);m_data.insert(QStringLiteral("p/%1").arg(id),p);if(p>=1.0&&!isUnlocked(id)){unlock(id);return;}persist();emit changed();}
