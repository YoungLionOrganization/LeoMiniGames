// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <QObject>
#include <QHash>

class GameInput final : public QObject
{
    Q_OBJECT
public:
    explicit GameInput(QObject *parent = nullptr);
    Q_INVOKABLE void press(const QString &action);
    Q_INVOKABLE void press(const QString &action, qreal value);
    Q_INVOKABLE void release(const QString &action);
    Q_INVOKABLE void setValue(const QString &action, qreal value);
    Q_INVOKABLE bool isPressed(const QString &action) const;
    Q_INVOKABLE qreal value(const QString &action) const;
    Q_INVOKABLE void reset();
signals:
    void actionPressed(const QString &action, qreal value);
    void actionReleased(const QString &action);
    void actionValueChanged(const QString &action, qreal value);
private:
    QHash<QString, qreal> m_values;
};
