// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <QObject>
#include <QString>
class QQmlApplicationEngine;
class PluginDiagnostics final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString lastError READ lastError NOTIFY lastErrorChanged)
public:
    explicit PluginDiagnostics(QObject *parent=nullptr);
    QString lastError() const;
    void attach(QQmlApplicationEngine *engine);
    void activate(const QString &gameId,const QString &version,const QString &source);
    Q_INVOKABLE void log(const QString &level,const QString &message);
    Q_INVOKABLE void log(const QString &level,const QString &message,const QString &source);
    Q_INVOKABLE void log(const QString &level,const QString &message,const QString &source,int line);
    Q_INVOKABLE void clear();
signals:void lastErrorChanged();void diagnostic(const QString &line);
private:
    QString logPath() const; QString m_gameId,m_version,m_source,m_lastError;
};
