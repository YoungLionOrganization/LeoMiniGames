// SPDX-License-Identifier: GPL-3.0-or-later
#include "GameStats.h"
#include "AppPaths.h"
#include <QCborValue>
#include <QDir>
#include <QFile>
#include <QSaveFile>
GameStats::GameStats(AppPaths *paths, QObject *parent) : QObject(parent), m_paths(paths) {}
QString GameStats::gameId() const { return m_gameId; }
QString GameStats::path() const { if (!m_paths || m_gameId.isEmpty()) return QString{}; const QString dir = m_paths->saves()+QLatin1Char('/')+m_gameId; QDir().mkpath(dir); return dir+QStringLiteral("/stats.cbor"); }
void GameStats::load(){ m_data.clear(); QFile f(path()); if (!f.open(QIODevice::ReadOnly)) return; QCborParserError e; const QCborValue v=QCborValue::fromCbor(f.readAll(),&e); if(e.error==QCborError::NoError&&v.isMap())m_data=v.toVariant().toMap(); }
void GameStats::persist() const { QSaveFile f(path()); if(!f.open(QIODevice::WriteOnly))return; f.write(QCborValue::fromVariant(m_data).toCbor()); f.commit(); }
void GameStats::activate(const QString &gameId){ if(m_gameId==gameId)return; endSession(); m_gameId=gameId; load(); emit changed(); }
qint64 GameStats::highScore() const{return highScore(QStringLiteral("default"));}
qint64 GameStats::highScore(const QString &name) const { return m_data.value(QStringLiteral("high/%1").arg(name),0).toLongLong(); }
bool GameStats::submitHighScore(qint64 score){return submitHighScore(score,QStringLiteral("default"));}
bool GameStats::submitHighScore(qint64 score,const QString &name){ if(score<=highScore(name))return false; m_data.insert(QStringLiteral("high/%1").arg(name),score);persist();emit changed();return true; }
qint64 GameStats::counter(const QString &name) const{return m_data.value(QStringLiteral("counter/%1").arg(name),0).toLongLong();}
void GameStats::setCounter(const QString &name,qint64 value){if(name.isEmpty())return;m_data.insert(QStringLiteral("counter/%1").arg(name),value);persist();emit changed();}
qint64 GameStats::increment(const QString &name){return increment(name,1);}
qint64 GameStats::increment(const QString &name,qint64 amount){const qint64 v=counter(name)+amount;setCounter(name,v);return v;}
qint64 GameStats::gamesPlayed() const{return m_data.value(QStringLiteral("gamesPlayed"),0).toLongLong();}
qint64 GameStats::totalTimeMs() const{return m_data.value(QStringLiteral("totalTimeMs"),0).toLongLong();}
void GameStats::startSession(){ if(m_gameId.isEmpty())return; m_data.insert(QStringLiteral("gamesPlayed"),gamesPlayed()+1); m_session.restart(); persist(); emit changed(); }
void GameStats::endSession(){ if(!m_session.isValid()||m_gameId.isEmpty())return; m_data.insert(QStringLiteral("totalTimeMs"),totalTimeMs()+m_session.elapsed());m_session.invalidate();persist();emit changed(); }
