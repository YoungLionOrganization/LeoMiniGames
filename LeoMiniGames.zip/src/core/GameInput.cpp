// SPDX-License-Identifier: GPL-3.0-or-later
#include "GameInput.h"
#include <QtGlobal>
GameInput::GameInput(QObject *parent) : QObject(parent) {}
void GameInput::press(const QString &action) { press(action, 1.0); }
void GameInput::press(const QString &action, qreal value) { if (action.isEmpty()) return; value = qBound<qreal>(-1.0, value, 1.0); m_values.insert(action, value); emit actionPressed(action, value); emit actionValueChanged(action, value); }
void GameInput::release(const QString &action) { if (action.isEmpty()) return; m_values.remove(action); emit actionReleased(action); emit actionValueChanged(action, 0.0); }
void GameInput::setValue(const QString &action, qreal value) { if (qFuzzyIsNull(value)) { release(action); return; } press(action, value); }
bool GameInput::isPressed(const QString &action) const { return m_values.contains(action) && !qFuzzyIsNull(m_values.value(action)); }
qreal GameInput::value(const QString &action) const { return m_values.value(action, 0.0); }
void GameInput::reset() { const auto keys = m_values.keys(); m_values.clear(); for (const QString &k : keys) { emit actionReleased(k); emit actionValueChanged(k, 0.0); } }
