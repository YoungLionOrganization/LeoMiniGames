// SPDX-License-Identifier: GPL-3.0-or-later
#include "PluginDiagnostics.h"
#include <QQmlApplicationEngine>
#include <QQmlError>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QStandardPaths>
#include <QTextStream>
PluginDiagnostics::PluginDiagnostics(QObject *parent):QObject(parent){}
QString PluginDiagnostics::lastError() const{return m_lastError;}
QString PluginDiagnostics::logPath() const{const QString d=QStandardPaths::writableLocation(QStandardPaths::AppDataLocation)+QStringLiteral("/logs");QDir().mkpath(d);return d+QStringLiteral("/plugins.log");}
void PluginDiagnostics::attach(QQmlApplicationEngine *engine){if(!engine)return;connect(engine,&QQmlEngine::warnings,this,[this](const QList<QQmlError>&errors){for(const QQmlError&e:errors)log(QStringLiteral("qml"),e.description(),e.url().toString(),e.line());});}
void PluginDiagnostics::activate(const QString &gameId,const QString &version,const QString &source){m_gameId=gameId;m_version=version;m_source=source;clear();}
void PluginDiagnostics::log(const QString &level,const QString &message){log(level,message,QString{},0);}
void PluginDiagnostics::log(const QString &level,const QString &message,const QString &source){log(level,message,source,0);}
void PluginDiagnostics::log(const QString &level,const QString &message,const QString &source,int line){const QString text=QStringLiteral("%1 [%2] game=%3 version=%4 type=%5 source=%6:%7 %8").arg(QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs),level,m_gameId,m_version,m_source,source).arg(line).arg(message);QFile f(logPath());if(f.open(QIODevice::WriteOnly|QIODevice::Append|QIODevice::Text)){QTextStream out(&f);out<<text<<'\n';}if(level.compare(QStringLiteral("error"),Qt::CaseInsensitive)==0||level==QStringLiteral("qml")){m_lastError=message;emit lastErrorChanged();}emit diagnostic(text);}
void PluginDiagnostics::clear(){if(m_lastError.isEmpty())return;m_lastError.clear();emit lastErrorChanged();}
