// SPDX-License-Identifier: GPL-3.0-or-later
#include "GameAudio.h"
#include "AudioManager.h"
#include "SettingsManager.h"
#include <QAudioOutput>
#include <QMediaPlayer>
#include <QtGlobal>
struct GameAudio::Impl{QAudioOutput output;QMediaPlayer player;bool resumeMusic=false;QString musicGroup=QStringLiteral("music");};
GameAudio::GameAudio(AudioManager *legacy,SettingsManager *settings,QObject *parent):QObject(parent),m_impl(std::make_unique<Impl>()),m_legacy(legacy),m_settings(settings){m_impl->player.setAudioOutput(&m_impl->output);connect(&m_impl->player,&QMediaPlayer::mediaStatusChanged,this,[this](QMediaPlayer::MediaStatus s){if(s==QMediaPlayer::EndOfMedia&&m_impl->player.loops()==QMediaPlayer::Infinite)m_impl->player.setPosition(0);});if(m_settings){connect(m_settings,&SettingsManager::soundVolumeChanged,this,&GameAudio::updateMusicVolume);connect(m_settings,&SettingsManager::soundEnabledChanged,this,&GameAudio::updateMusicVolume);}updateMusicVolume();}
GameAudio::~GameAudio()=default;
QString GameAudio::normalizedGroup(const QString &group) const{const QString value=group.trimmed().toLower();return value==QStringLiteral("music")||value==QStringLiteral("ui")||value==QStringLiteral("ambient")?value:QStringLiteral("sfx");}
qreal GameAudio::groupVolume(const QString &group) const{if(!m_settings)return 1.0;return qBound<qreal>(0.0,m_settings->value(QStringLiteral("audio/groups/%1").arg(normalizedGroup(group)),1.0).toReal(),1.0);}
qreal GameAudio::volume(const QString &group) const{return groupVolume(group);}
void GameAudio::setVolume(const QString &group,qreal value){if(!m_settings||group.isEmpty())return;m_settings->setValue(QStringLiteral("audio/groups/%1").arg(normalizedGroup(group)),qBound<qreal>(0.0,value,1.0));updateMusicVolume();}
void GameAudio::playEffect(const QUrl &url){playEffect(url,1.0,QStringLiteral("sfx"));}
void GameAudio::playEffect(const QUrl &url,qreal gain){playEffect(url,gain,QStringLiteral("sfx"));}
void GameAudio::playEffect(const QUrl &url,qreal gain,const QString &group){if(m_legacy)m_legacy->playUrl(url,gain*groupVolume(group));}
void GameAudio::preload(const QUrl &url){if(m_legacy)m_legacy->preload(url);}
void GameAudio::playMusic(const QUrl &url){playMusic(url,true,QStringLiteral("music"));}
void GameAudio::playMusic(const QUrl &url,bool loop){playMusic(url,loop,QStringLiteral("music"));}
void GameAudio::playMusic(const QUrl &url,bool loop,const QString &group){if(!url.isValid()||url.isEmpty())return;const QString s=url.scheme().toLower();if(s!=QStringLiteral("qrc")&&s!=QStringLiteral("file"))return;m_impl->resumeMusic=false;m_impl->musicGroup=normalizedGroup(group);m_impl->player.setSource(url);m_impl->player.setLoops(loop?QMediaPlayer::Infinite:1);updateMusicVolume();m_impl->player.play();}
void GameAudio::stopMusic(){m_impl->resumeMusic=false;m_impl->player.stop();}
void GameAudio::pauseAll(){if(m_legacy)m_legacy->stopAll();m_impl->resumeMusic=m_impl->player.playbackState()==QMediaPlayer::PlayingState;if(m_impl->resumeMusic)m_impl->player.pause();}
void GameAudio::resumeAll(){if(m_impl->resumeMusic){m_impl->resumeMusic=false;m_impl->player.play();}}
void GameAudio::updateMusicVolume(){qreal master=1.0;if(m_settings){master=m_settings->soundEnabled()?m_settings->soundVolume():0.0;}m_impl->output.setVolume(qBound<qreal>(0.0,master*groupVolume(m_impl->musicGroup),1.0));}
