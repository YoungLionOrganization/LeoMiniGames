// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <QObject>
#include <QPointer>
#include <QUrl>

class GameRegistry;

class AppController final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QObject *currentGame READ currentGame NOTIFY currentGameChanged)
    Q_PROPERTY(QUrl currentGameUrl READ currentGameUrl NOTIFY currentGameChanged)
    Q_PROPERTY(QString currentGameId READ currentGameId NOTIFY currentGameChanged)
public:
    explicit AppController(GameRegistry *registry, QObject *parent = nullptr);
    QObject *currentGame() const; QUrl currentGameUrl() const; QString currentGameId() const;
    Q_INVOKABLE bool openGame(const QString &id); Q_INVOKABLE void closeGame();
signals:
    void currentGameChanged(); void gameOpened(); void gameClosed(); void openFailed(const QString &message);
private:
    GameRegistry *m_registry = nullptr; QPointer<QObject> m_currentGame; QUrl m_currentGameUrl; QString m_currentGameId;
};
