// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include <QObject>
#include <QString>
#include <QUrl>
#include <memory>

class SettingsManager;

class AudioManager final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool available READ available CONSTANT)

public:
    explicit AudioManager(SettingsManager *settings, QObject *parent = nullptr);
    ~AudioManager() override;

    bool available() const;
    Q_INVOKABLE void play(const QString &name);
    Q_INVOKABLE void playUrl(const QUrl &url);
    Q_INVOKABLE void playUrl(const QUrl &url, qreal gain);
    Q_INVOKABLE void preload(const QUrl &url);
    Q_INVOKABLE void stopAll();

private:
    struct Impl;
    std::unique_ptr<Impl> m_impl;
    SettingsManager *m_settings = nullptr;

    void updateVolume();
    qreal effectiveVolume(qreal gain = 1.0) const;
};
