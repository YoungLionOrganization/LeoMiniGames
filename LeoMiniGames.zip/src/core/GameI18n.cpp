// SPDX-License-Identifier: GPL-3.0-or-later
#include "GameI18n.h"
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QRegularExpression>

GameI18n::GameI18n(QObject *parent) : QObject(parent) {}
QString GameI18n::gameId() const { return m_gameId; }
QString GameI18n::language() const { return m_language; }
QString GameI18n::defaultLocale() const { return m_defaultLocale; }
QString GameI18n::normalized(const QString &locale) const { QString v = locale.trimmed().toLower(); v.replace(QLatin1Char('-'), QLatin1Char('_')); static const QRegularExpression safe(QStringLiteral("^[a-z0-9]{2,12}(?:_[a-z0-9]{2,12})?$")); return safe.match(v).hasMatch() ? v : QStringLiteral("en"); }

QVariantMap GameI18n::loadLocale(const QString &locale) const
{
    const QString code = normalized(locale);
    if (m_cache.contains(code)) return m_cache.value(code);
    QVariantMap map;
    if (!m_gameId.isEmpty()) {
        QFile file(QStringLiteral(":/mods/%1/i18n/%2.json").arg(m_gameId, code));
        if (file.open(QIODevice::ReadOnly)) {
            QJsonParseError error;
            const QJsonDocument doc = QJsonDocument::fromJson(file.readAll(), &error);
            if (error.error == QJsonParseError::NoError && doc.isObject()) map = doc.object().toVariantMap();
        }
    }
    m_cache.insert(code, map);
    return map;
}

QString GameI18n::text(const QString &key) const
{
    return text(key, QString{});
}

QString GameI18n::text(const QString &key, const QString &fallback) const
{
    const QString requested = normalized(m_language);
    const QString base = requested.section(QLatin1Char('_'), 0, 0);
    const QStringList chain = {requested, base, normalized(m_defaultLocale), QStringLiteral("en")};
    for (const QString &locale : chain) {
        const QVariantMap map = loadLocale(locale);
        if (map.contains(key)) return map.value(key).toString();
    }
    return fallback.isEmpty() ? key : fallback;
}

void GameI18n::activate(const QString &gameId, const QString &defaultLocale, const QStringList &locales)
{
    m_gameId = gameId; m_defaultLocale = normalized(defaultLocale); m_locales = locales; m_cache.clear(); emit changed();
}
void GameI18n::setLanguage(const QString &language) { const QString value = normalized(language); if (m_language == value) return; m_language = value; m_cache.clear(); emit changed(); }
