// SPDX-License-Identifier: GPL-3.0-or-later
#include "AppController.h"
#include "GameRegistry.h"
AppController::AppController(GameRegistry *registry,QObject *parent):QObject(parent),m_registry(registry){}
QObject *AppController::currentGame() const{return m_currentGame.data();}
QUrl AppController::currentGameUrl() const{return m_currentGameUrl;}
QString AppController::currentGameId() const{return m_currentGameId;}
bool AppController::openGame(const QString &id)
{
    if (!m_registry) return false;
    closeGame();
    const QUrl url=m_registry->entryUrl(id);
    const QString source=m_registry->sourceFor(id);
    QObject *game=m_registry->createGame(id,this);
    const bool needsNativeObject=source!=QStringLiteral("ExternalRcc");
    if(!url.isValid()||url.isEmpty()||(needsNativeObject&&!game)){
        if(game)game->deleteLater();emit openFailed(QStringLiteral("Could not open game: %1").arg(id));return false;
    }
    m_currentGame=game;m_currentGameUrl=url;m_currentGameId=id;emit currentGameChanged();emit gameOpened();return true;
}
void AppController::closeGame(){if (!m_currentGame && m_currentGameId.isEmpty()) return;if(m_currentGame)m_currentGame->deleteLater();m_currentGame.clear();m_currentGameUrl=QUrl{};m_currentGameId.clear();emit currentGameChanged();emit gameClosed();}
