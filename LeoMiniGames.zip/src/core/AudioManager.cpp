// SPDX-License-Identifier: GPL-3.0-or-later
#include "AudioManager.h"
#include "SettingsManager.h"

#include <QHash>
#include <QSoundEffect>
#include <QtGlobal>
#include <utility>

struct AudioManager::Impl
{
    QHash<QString, QSoundEffect *> effects;
    QHash<QString, QSoundEffect *> dynamicEffects;
};

AudioManager::AudioManager(SettingsManager *settings, QObject *parent)
    : QObject(parent), m_impl(std::make_unique<Impl>()), m_settings(settings)
{
    const auto add = [this](const QString &name, const QString &resource) {
        auto *effect = new QSoundEffect(this);
        effect->setSource(QUrl(resource));
        effect->setLoopCount(1);
        m_impl->effects.insert(name, effect);
    };

    add(QStringLiteral("click"), QStringLiteral("qrc:/sfx/click.wav"));
    add(QStringLiteral("move"), QStringLiteral("qrc:/sfx/move.wav"));
    add(QStringLiteral("card"), QStringLiteral("qrc:/sfx/card.wav"));
    add(QStringLiteral("flag"), QStringLiteral("qrc:/sfx/flag.wav"));
    add(QStringLiteral("flip"), QStringLiteral("qrc:/sfx/flip.wav"));
    add(QStringLiteral("win"), QStringLiteral("qrc:/sfx/win.wav"));
    add(QStringLiteral("lose"), QStringLiteral("qrc:/sfx/lose.wav"));
    add(QStringLiteral("success"), QStringLiteral("qrc:/sfx/success.wav"));
    add(QStringLiteral("error"), QStringLiteral("qrc:/sfx/error.wav"));
    add(QStringLiteral("deal"), QStringLiteral("qrc:/sfx/deal.wav"));
    add(QStringLiteral("shuffle"), QStringLiteral("qrc:/sfx/shuffle.wav"));
    add(QStringLiteral("tap"), QStringLiteral("qrc:/sfx/tap.wav"));
    add(QStringLiteral("match"), QStringLiteral("qrc:/sfx/match.wav"));
    add(QStringLiteral("miss"), QStringLiteral("qrc:/sfx/miss.wav"));
    add(QStringLiteral("merge"), QStringLiteral("qrc:/sfx/merge.wav"));
    add(QStringLiteral("ready"), QStringLiteral("qrc:/sfx/ready.wav"));
    add(QStringLiteral("download"), QStringLiteral("qrc:/sfx/download.wav"));
    add(QStringLiteral("install"), QStringLiteral("qrc:/sfx/install.wav"));
    add(QStringLiteral("uninstall"), QStringLiteral("qrc:/sfx/uninstall.wav"));

    updateVolume();
    connect(m_settings, &SettingsManager::soundVolumeChanged, this, &AudioManager::updateVolume);
    connect(m_settings, &SettingsManager::soundEnabledChanged, this, &AudioManager::updateVolume);
}

AudioManager::~AudioManager() = default;

bool AudioManager::available() const { return true; }

qreal AudioManager::effectiveVolume(qreal gain) const
{
    if (!m_settings || !m_settings->soundEnabled())
        return 0.0;
    return qBound<qreal>(0.0, m_settings->soundVolume() * qBound<qreal>(0.0, gain, 2.0), 1.0);
}

void AudioManager::play(const QString &name)
{
    QSoundEffect *effect = m_impl->effects.value(name, nullptr);
    if (!effect)
        return;
    effect->setVolume(effectiveVolume());
    if (effect->isPlaying())
        effect->stop();
    effect->play();
}

void AudioManager::preload(const QUrl &url)
{
    if (!url.isValid() || url.isEmpty())
        return;
    const QString key = url.toString();
    if (m_impl->dynamicEffects.contains(key))
        return;
    auto *effect = new QSoundEffect(this);
    effect->setLoopCount(1);
    effect->setVolume(effectiveVolume());
    effect->setSource(url);
    m_impl->dynamicEffects.insert(key, effect);
}

void AudioManager::playUrl(const QUrl &url)
{
    playUrl(url, 1.0);
}

void AudioManager::playUrl(const QUrl &url, qreal gain)
{
    if (!url.isValid() || url.isEmpty() || effectiveVolume(gain) <= 0.0)
        return;
    const QString scheme = url.scheme().toLower();
    if (scheme != QStringLiteral("qrc") && scheme != QStringLiteral("file"))
        return; // Downloadable mods may only play local resources.

    preload(url);
    QSoundEffect *effect = m_impl->dynamicEffects.value(url.toString(), nullptr);
    if (!effect)
        return;
    effect->setVolume(effectiveVolume(gain));
    if (effect->isPlaying())
        effect->stop();
    effect->play();
}

void AudioManager::stopAll()
{
    for (QSoundEffect *effect : std::as_const(m_impl->effects))
        effect->stop();
    for (QSoundEffect *effect : std::as_const(m_impl->dynamicEffects))
        effect->stop();
}

void AudioManager::updateVolume()
{
    const qreal volume = effectiveVolume();
    for (QSoundEffect *effect : std::as_const(m_impl->effects))
        effect->setVolume(volume);
    for (QSoundEffect *effect : std::as_const(m_impl->dynamicEffects))
        effect->setVolume(volume);
}
