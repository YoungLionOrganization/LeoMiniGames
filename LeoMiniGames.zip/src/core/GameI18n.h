// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <QObject>
#include <QHash>
#include <QVariantMap>

class GameI18n final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString gameId READ gameId NOTIFY changed)
    Q_PROPERTY(QString language READ language WRITE setLanguage NOTIFY changed)
    Q_PROPERTY(QString defaultLocale READ defaultLocale NOTIFY changed)
public:
    explicit GameI18n(QObject *parent = nullptr);
    QString gameId() const; QString language() const; QString defaultLocale() const;
    Q_INVOKABLE QString text(const QString &key) const;
    Q_INVOKABLE QString text(const QString &key, const QString &fallback) const;
    void activate(const QString &gameId, const QString &defaultLocale, const QStringList &locales);
public slots:
    void setLanguage(const QString &language);
signals: void changed();
private:
    QVariantMap loadLocale(const QString &locale) const;
    QString normalized(const QString &locale) const;
    QString m_gameId; QString m_language = QStringLiteral("en"); QString m_defaultLocale = QStringLiteral("en"); QStringList m_locales;
    mutable QHash<QString, QVariantMap> m_cache;
};
