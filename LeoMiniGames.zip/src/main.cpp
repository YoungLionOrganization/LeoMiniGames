// SPDX-License-Identifier: GPL-3.0-or-later
#include <QGuiApplication>
#include <QCoreApplication>
#include <QIcon>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>
#include <QSslSocket>
#include <QtPlugin>

#include "core/Achievements.h"
#include "core/AppController.h"
#include "core/AppPaths.h"
#include "core/AudioManager.h"
#include "core/BackNavigation.h"
#include "core/GameAudio.h"
#include "core/GameI18n.h"
#include "core/GameInput.h"
#include "core/GameRandom.h"
#include "core/GameEvents.h"
#include "core/GameClock.h"
#include "core/GameLifecycle.h"
#include "core/GameRegistry.h"
#include "core/GameSave.h"
#include "core/GameSettings.h"
#include "core/GameStats.h"
#include "core/GameViewport.h"
#include "core/Haptics.h"
#include "core/LanguageManager.h"
#include "core/ModFilterProxyModel.h"
#include "core/ModManager.h"
#include "core/PluginDiagnostics.h"
#include "core/PluginManager.h"
#include "core/SettingsManager.h"
#include "core/ThemeManager.h"
#include "core/ThemeCatalogManager.h"
#include "core/ThemeInstalledModel.h"
#include "core/ThemeFilterProxyModel.h"

Q_IMPORT_PLUGIN(XoxPlugin)
Q_IMPORT_PLUGIN(BlackjackPlugin)
Q_IMPORT_PLUGIN(MinesweeperPlugin)
Q_IMPORT_PLUGIN(TwentyFortyEightPlugin)
Q_IMPORT_PLUGIN(MemoryMatchPlugin)
Q_IMPORT_PLUGIN(ReactionTapPlugin)

int main(int argc, char *argv[])
{
#if defined(Q_OS_ANDROID) && defined(LEOMINIGAMES_ANDROID_OPENSSL_SUFFIX_3)
    qputenv("ANDROID_OPENSSL_SUFFIX", "_3");
#endif
    QGuiApplication app(argc, argv);
    app.setOrganizationName(QStringLiteral("YoungLion"));
    app.setOrganizationDomain(QStringLiteral("xyz.younglion.leominigames"));
    app.setApplicationName(QStringLiteral("LeoMiniGames"));
    app.setApplicationVersion(QStringLiteral("0.6.2"));
    app.setApplicationDisplayName(QStringLiteral("LeoMiniGames"));
    app.setWindowIcon(QIcon(QStringLiteral(":/branding/leominigames_icon.png")));
    QQuickStyle::setStyle(QStringLiteral("Basic"));

    AppPaths paths;
    SettingsManager settings;
    ThemeManager theme(&paths);
    ThemeCatalogManager themeCatalog(&paths, &settings, &theme);
    ThemeInstalledModel themeInstalledModel(&theme, &themeCatalog);
    ThemeFilterProxyModel themeExplore;
    themeExplore.setSourceModel(&themeCatalog);
    themeExplore.setSortMode(QStringLiteral("updated"));
    ThemeFilterProxyModel themeInstalled;
    themeInstalled.setSourceModel(&themeInstalledModel);
    themeInstalled.setSortMode(QStringLiteral("active"));
    AudioManager audio(&settings);
    PluginManager plugins(&paths);
    LanguageManager language(&settings);
    ModManager mods(&paths, &settings);
    GameRegistry registry(&plugins, &mods);
    AppController controller(&registry);
    BackNavigation backNavigation;

    GameSettings gameSettings(&settings);
    GameSave gameSave(&paths);
    GameInput gameInput;
    GameRandom gameRandom;
    GameEvents gameEvents;
    GameClock gameClock;
    GameViewport viewport;
    GameLifecycle lifecycle;
    GameI18n gameI18n;
    GameStats gameStats(&paths);
    Achievements achievements(&paths);
    GameAudio gameAudio(&audio, &settings);
    Haptics haptics;
    PluginDiagnostics diagnostics;

    ModFilterProxyModel modsExplore;
    modsExplore.setSourceModel(&mods);
    modsExplore.setMode(QStringLiteral("catalog"));
    modsExplore.setSortMode(QStringLiteral("updated"));
    ModFilterProxyModel modsInstalled;
    modsInstalled.setSourceModel(&mods);
    modsInstalled.setMode(QStringLiteral("installed"));
    modsInstalled.setSortMode(QStringLiteral("name"));

    QQmlApplicationEngine engine;
    gameSave.setEngine(&engine);
    diagnostics.attach(&engine);
    language.setEngine(&engine);
    language.restore();
    gameI18n.setLanguage(language.language());

    QObject::connect(&language, &LanguageManager::languageChanged, &gameI18n, [&language, &gameI18n] {
        gameI18n.setLanguage(language.language());
    });
    QObject::connect(&controller, &AppController::gameOpened, &app, [&] {
        const QString id = controller.currentGameId();
        const QString version = registry.versionFor(id);
        const bool external = registry.sourceFor(id) == QStringLiteral("ExternalRcc");
        gameSettings.activate(id, external ? mods.settingsSchemaFor(id) : QVariantMap{});
        gameSave.activate(id, version, external ? mods.saveVersionFor(id) : registry.saveVersionFor(id));
        gameI18n.activate(id, external ? mods.defaultLocaleFor(id) : QStringLiteral("en"), external ? mods.localesFor(id) : QStringList{});
        gameStats.activate(id);
        achievements.activate(id);
        diagnostics.activate(id, version, registry.sourceFor(id));
        gameInput.reset();
    });
    QObject::connect(&lifecycle, &GameLifecycle::started, &gameStats, &GameStats::startSession);
    QObject::connect(&lifecycle, &GameLifecycle::started, &gameClock, &GameClock::reset);
    QObject::connect(&lifecycle, &GameLifecycle::paused, &gameClock, &GameClock::pause);
    QObject::connect(&lifecycle, &GameLifecycle::resumed, &gameClock, &GameClock::resume);
    QObject::connect(&lifecycle, &GameLifecycle::closed, &gameStats, &GameStats::endSession);
    QObject::connect(&controller, &AppController::gameClosed, &app, [&] {
        gameStats.endSession();
        gameInput.reset();
        gameAudio.stopMusic();
        gameSettings.activate(QString{});
        gameSave.activate(QString{}, QString{}, 1);
        gameI18n.activate(QString{}, QStringLiteral("en"), QStringList{});
        achievements.activate(QString{});
    });
    QObject::connect(&app, &QGuiApplication::applicationStateChanged, &app, [&](Qt::ApplicationState state) {
        if (controller.currentGameId().isEmpty())
            return;
        if (state == Qt::ApplicationInactive || state == Qt::ApplicationSuspended || state == Qt::ApplicationHidden) {
            lifecycle.pause();
            lifecycle.background();
            lifecycle.save();
            gameSave.autosave();
            gameAudio.pauseAll();
        } else if (state == Qt::ApplicationActive) {
            lifecycle.foreground();
            lifecycle.resume();
            gameAudio.resumeAll();
        }
    });

    engine.rootContext()->setContextProperty(QStringLiteral("App"), &controller);
    engine.rootContext()->setContextProperty(QStringLiteral("Paths"), &paths);
    engine.rootContext()->setContextProperty(QStringLiteral("Settings"), &settings);
    engine.rootContext()->setContextProperty(QStringLiteral("ThemeRuntime"), &theme);
    engine.rootContext()->setContextProperty(QStringLiteral("ThemeCatalog"), &themeCatalog);
    engine.rootContext()->setContextProperty(QStringLiteral("ThemesExplore"), &themeExplore);
    engine.rootContext()->setContextProperty(QStringLiteral("ThemesInstalled"), &themeInstalled);
    engine.rootContext()->setContextProperty(QStringLiteral("Audio"), &audio); // Legacy API
    engine.rootContext()->setContextProperty(QStringLiteral("Plugins"), &plugins); // Legacy API
    engine.rootContext()->setContextProperty(QStringLiteral("Lang"), &language);
    engine.rootContext()->setContextProperty(QStringLiteral("Mods"), &mods);
    engine.rootContext()->setContextProperty(QStringLiteral("Back"), &backNavigation);

    engine.rootContext()->setContextProperty(QStringLiteral("Games"), &registry);
    engine.rootContext()->setContextProperty(QStringLiteral("ModsExplore"), &modsExplore);
    engine.rootContext()->setContextProperty(QStringLiteral("ModsInstalled"), &modsInstalled);
    engine.rootContext()->setContextProperty(QStringLiteral("GameSettings"), &gameSettings);
    engine.rootContext()->setContextProperty(QStringLiteral("GameSave"), &gameSave);
    engine.rootContext()->setContextProperty(QStringLiteral("GameInput"), &gameInput);
    engine.rootContext()->setContextProperty(QStringLiteral("GameRandom"), &gameRandom);
    engine.rootContext()->setContextProperty(QStringLiteral("GameEvents"), &gameEvents);
    engine.rootContext()->setContextProperty(QStringLiteral("GameClock"), &gameClock);
    engine.rootContext()->setContextProperty(QStringLiteral("GameTheme"), &theme);
    engine.rootContext()->setContextProperty(QStringLiteral("Viewport"), &viewport);
    engine.rootContext()->setContextProperty(QStringLiteral("Lifecycle"), &lifecycle);
    engine.rootContext()->setContextProperty(QStringLiteral("GameI18n"), &gameI18n);
    engine.rootContext()->setContextProperty(QStringLiteral("GameStats"), &gameStats);
    engine.rootContext()->setContextProperty(QStringLiteral("Achievements"), &achievements);
    engine.rootContext()->setContextProperty(QStringLiteral("GameAudio"), &gameAudio);
    engine.rootContext()->setContextProperty(QStringLiteral("Haptics"), &haptics);
    engine.rootContext()->setContextProperty(QStringLiteral("GameLogger"), &diagnostics);

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
                     &app, [] { QCoreApplication::exit(-1); }, Qt::QueuedConnection);
    engine.loadFromModule(QStringLiteral("LeoMiniGames"), QStringLiteral("Main"));
    return app.exec();
}
