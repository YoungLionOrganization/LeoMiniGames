# Security Policy

## Plugin boundary

RCC plugins are data/QML resources, not trusted native code. A manifest cannot grant itself verified-publisher or Level 3 status.

Trusted native plugins are desktop-only in the current loader and require an entry in the local `plugins/trusted-native.json` trust snapshot with `reviewed: true`, `publisher_verified: true` and an exact SHA-256 of the native library. Signature verification fields are reserved for a later backend/client protocol.

## Downloads

RCC catalog installs require HTTPS, an expected size, SHA-256 verification, safe entry paths, the existing `rcc-v1` package format and Qt resource registration. Replacement installs use rollback to retain the previous working package if activation fails.

## Reporting

Do not publish exploit details that put users at immediate risk before a fix is available. Include application version, platform, plugin ID/version and relevant diagnostics when reporting a plugin issue.
